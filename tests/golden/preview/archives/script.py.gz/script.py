import os

def main():
    print(os.getcwd())  # cwd
